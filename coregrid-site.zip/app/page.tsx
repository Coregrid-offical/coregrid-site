
'use client';

import CoreGridKonanStyleSite from "@/components/CoreGridKonanStyleSite";

export default function Page() {
  return <CoreGridKonanStyleSite />;
}
