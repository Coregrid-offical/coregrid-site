
export const metadata = {
  title: "CoreGrid – Company Site",
  description: "PV · ESS · PCS · EMS · 기자재 유통 – CoreGrid corporate site"
};

import "./globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
