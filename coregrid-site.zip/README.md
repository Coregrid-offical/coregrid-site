
# CoreGrid Site (Next.js + Tailwind, Vercel-ready)

## Quick Start
```bash
npm i
npm run dev
```
Deploy on Vercel by importing this repo. No extra config needed.
