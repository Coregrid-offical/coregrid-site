
import * as React from "react";

export function Badge({ className = "", children, variant = "default" }: React.PropsWithChildren<{ className?: string, variant?: "default" | "secondary" }>) {
  const base = "inline-flex items-center rounded-full px-3 py-1 text-xs font-medium border";
  const variants = {
    default: "bg-slate-900 text-white border-slate-900",
    secondary: "bg-slate-100 text-slate-700 border-slate-200"
  };
  return <span className={[base, variants[variant], className].join(" ")}>{children}</span>;
}
