
import * as React from "react";

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "default" | "outline";
  size?: "sm" | "md";
  asChild?: boolean;
};

export function Button({ className = "", variant = "default", size = "md", asChild, children, ...props }: ButtonProps) {
  const base = "inline-flex items-center justify-center rounded-2xl font-medium transition px-4 py-2 shadow-sm";
  const variants = {
    default: "bg-slate-900 text-white hover:opacity-90",
    outline: "border border-slate-300 text-slate-800 bg-white hover:bg-slate-50"
  };
  const sizes = {
    sm: "text-sm px-3 py-1.5",
    md: "text-base px-4 py-2"
  };
  if (asChild) {
    // If used asChild, we just render a span wrapper expecting an anchor inside in our usage.
    return <span className={[base, variants[variant], sizes[size], className].join(" ")} {...(props as any)}>{children}</span>;
  }
  return <button className={[base, variants[variant], sizes[size], className].join(" ")} {...props}>{children}</button>;
}
